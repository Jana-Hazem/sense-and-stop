# S1 empirical ranges (PRELIMINARY - 3 animals, 15 baseline waves (after manual exclusions))

| Feature | Mean | Animal-mean range | Wave SD | n |
|---|---|---|---|---|
| fwhm_s | 42.76 | [36.2, 55.83] | 13.05 | 15 |
| rise_10pct_s | 35.19 | [25.4, 46.17] | 17.81 | 15 |
| decay_10pct_s | 40.68 | [28.0, 47.2] | 14.25 | 15 |
| dc_to_doppler_delay_s | 55.89 | [47.67, 61.0] | 17.08 | 15 |
| dc_amp_V | 0.11 | [0.08, 0.15] | 0.05 | 15 |
| doppler_amp_V | 1.18 | [0.69, 1.78] | 0.5 | 15 |

Literature-derived pulse width (NOT measured):
- narrow (Sci. Rep. 8:17656, 2018, doi:10.1038/s41598-018-36330-2): 1.69-2.13 mm
- broad (Front. Cell. Neurosci. 16:837650, 2022, doi:10.3389/fncel.2022.837650): 1.47-6.61 mm

Manually excluded waves: 13 (see manual_exclusions.csv)